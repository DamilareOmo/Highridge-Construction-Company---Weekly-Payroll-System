# ============================================================
# Highridge Construction Company - Weekly Payroll System
# Author: Sodiq Omoniyi
# Role: Software Engineer
# Description: The system dynamically generates employee data (400+ workers), 
#   processes weekly payroll, and assigns tier levels.
# ============================================================

set.seed(42)  # For reproducibility

# --- Constants ---
fist_name <- c("Toheeb", "David", "John", "Andrew", "Victor", "Adeola", "Joseph", "Abdulwasiu",
                "Opeyemi", "Amos", "Robert", "Matthew", "Tom", "Michael", "Adebayo")
last_name <- c("Semiu", "William", "Rita", "Richard", "Amaka", "Susan", "Theresa", "Aisha",
               "Jemima", "Sherifdeen", "Charles", "Michael", "Grace", "Sanjay", "Ella")
genders <- c("Male", "Female")

num_workers <- 400

# --- Generate Workers ---
generate_workers <- function(count) {
  workers <- vector("list", count)
  
  for (i in seq_len(count)) {
    gender <- sample(GENDERS, 1)
    salary <- round(runif(1, min = 5000, max = 35000), 2)
    
    first_name <- sample(fist_name, 1)
    last_name <- sample(last_name, 1)
    
    workers[[i]] <- list(
      id     = i,
      name   = paste(first_name, last_name, paste0("Worker-", i)),
      gender = gender,
      salary = salary
    )
  }
  
  return(workers)
}

#--- Assign the employee level based on salary and gender. ---
employee_level_assigning <- function(salary, gender) {
  level <- "N/A"
  #--- Rule 1: salary > $10,000 and < $20,000 then assigns A1. ---
  if (salary > 10000 && salary < 20000) {
    level <- "A1"
  }
  
  #--- Rule 2: salary > $7,500 and < $30,000 AND female then assigns A5-F. ---
  if (salary > 7500 && salary < 30000 && gender == "Female") {
    level <- "A5-F"
  }
  
  return(level)
}

cat("========== WEEKLY PAYMENT SLIPS ==========\n\n")
# Print all payment slips
for (worker in workers) {
  cat(generate_payment_slip(worker), "\n")
}

# --- Generate Payment Slip ---
generate_payment_slip <- function(worker) {
  level <- classify_employee(worker$salary, worker$gender)
  separator <- paste(rep("=", 35), collapse = "")
  slip <- paste0(
    separator, "\n",
    "  HIGHRIDGE CONSTRUCTION COMPANY\n",
    "  Weekly Payment Slip\n",
    separator, "\n",
    "  Employee ID : ", worker$id, "\n",
    "  Name        : ", worker$name, "\n",
    "  Gender      : ", worker$gender, "\n",
    sprintf("  Salary      : $%s\n", formatC(worker$salary, format = "f", digits = 2, big.mark = ",")),
    "  Level       : ", level, "\n",
    separator, "\n"
  )
  return(slip)
}


# --- Main ---
tryCatch({
  workers <- generate_workers(NUM_WORKERS)
  
  if (length(workers) == 0) {
    stop("Worker list is empty. Cannot generate payment slips.")
  }
  
  cat(sprintf("Generating payment slips for %d workers...\n\n", length(workers)))
  
  for (worker in workers) {
    tryCatch({
      slip <- generate_payment_slip(worker)
      cat(slip)
    }, error = function(e) {
      cat(sprintf("[ERROR] Problem with worker ID %s: %s\n", worker$id, e$message))
    })
  }
  
  cat(sprintf("\nDone. %d payment slips generated successfully.\n", length(workers)))
  
}, error = function(e) {
  cat(sprintf("[CRITICAL ERROR] %s\n", e$message))
})
