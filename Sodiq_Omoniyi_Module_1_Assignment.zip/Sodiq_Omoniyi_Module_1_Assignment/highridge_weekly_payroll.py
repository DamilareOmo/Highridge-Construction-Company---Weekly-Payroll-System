""""
Highridge Construction Company - Weekly Payroll System
Author: Sodiq Omoniyi
Role: Software Engineer
Description: The system dynamically generates employee data (400+ workers), processes weekly payroll, and assigns tier levels.
"""

import random

# --- Constants ---
first_name = [ "Toheeb", "David", "John", "Andrew", "Victor", "Adeola", "Joseph", "Abdulwasiu",
               "Opeyemi", "Amos", "Robert", "Matthew", "Tom", "Michael", "Adebayo"  ]
last_name = ["Semiu", "William", "Rita", "Richard", "Amaka", "Susan", "Theresa", "Aisha",
          "Jemima", "Sherifdeen", "Charles", "Michael", "Grace", "Sanjay", "Ella"]
genders = ["Male", "Female"]
num_workers = 400

# --- Generate Workers ---
def generate_workers(count):
    #--- Dynamically generate a list of worker dictionaries. ---
    workers = []
    for i in range(1, count + 1):
        gender = random.choice(genders)
        salary = round(random.uniform(5000, 35000), 2)
        worker = {
            "id": i,
            "name": f"{random.choice(first_name)} {random.choice(last_name)} Worker-{i}",
            "gender": gender,
            "salary": salary,
        }
        workers.append(worker)
    return workers

def employee_level_assigning(salary, gender):
    #--- Assign the employee level based on salary and gender. ---
    level = "N/A"
    #--- Rule 1: salary > $10,000 and < $20,000 then assigns A1. ---
    if 10_000 < salary < 20_000:
        level = "A1"
    #--- Rule 2: salary > $7,500 and < $30,000 AND female then assigns A5-F. ---
    if 7_500 < salary < 30_000 and gender == "Female":
        level = "A5-F"
    return level

print("========== WEEKLY PAYMENT SLIPS ==========\n")

def generate_payment_slip(worker):
    #--- Return a formatted payment slip string for a worker. ---
    level = employee_level_assigning(worker["salary"], worker["gender"])
    slip = (
        f"{'='*35}\n"
        f"  HIGHRIDGE CONSTRUCTION COMPANY\n"
        f"  Weekly Payment Slip\n"
        f"{'='*35}\n"
        f"  Employee ID : {worker['id']}\n"
        f"  Name        : {worker['name']}\n"
        f"  Gender      : {worker['gender']}\n"
        f"  Salary      : ${worker['salary']:,.2f}\n"
        f"  Level       : {level}\n"
        f"{'='*35}\n"
    )
    return slip

def main():
    #--- Main entry point: generate workers and print payment slips. ---
    try:
        workers = generate_workers(num_workers)

        if not workers:
            raise ValueError("Worker list is empty. Cannot generate payment slips.")

        print(f"Generating payment slips for {len(workers)} workers...\n")

        for worker in workers:
            try:
                slip = generate_payment_slip(worker)
                print(slip)
            except KeyError as e:
                print(f"[ERROR] Missing field for worker ID {worker.get('id', '?')}: {e}")
            except Exception as e:
                print(f"[ERROR] Unexpected error for worker ID {worker.get('id', '?')}: {e}")

        print(f"\nDone. {len(workers)} payment slips generated successfully.")

    except ValueError as e:
        print(f"[VALUE ERROR] {e}")
    except Exception as e:
        print(f"[CRITICAL ERROR] {e}")

if __name__ == "__main__":
    main()
